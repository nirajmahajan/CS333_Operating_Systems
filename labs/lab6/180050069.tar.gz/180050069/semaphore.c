/*----------xv6 sync lab----------*/
#include "types.h"
#include "x86.h"
#include "defs.h"
#include "semaphore.h"

int
sem_init(int index, int val)
{
  //to be done
  return 0;
}

int
sem_up(int index)
{
  //to be done
  return 0;
}

int
sem_down(int index)
{
  //to be done
  return 0;
}

/*----------xv6 sync lab end----------*/
